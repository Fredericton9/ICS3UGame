
Chess


The exe to play is in the folder CV1.0.1 and it is called run.exe.

If you want, make a shortcut outside of the CV1.0.1 folder that points to run.exe.